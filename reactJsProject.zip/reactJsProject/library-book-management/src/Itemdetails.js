import React,{useState,useEffect} from 'react';
import './App.css';
import axios from 'axios';
import {Link} from 'react-router-dom';

function Itemdetails({match}) {

	useEffect(() =>{
	fetchItems();
	},[]);

const [items,setItems]=useState([]);
var paramId=match.params.id;
console.log('==>',paramId);

const fetchItems=async()=>{
const itemDetails=await fetch('http://localhost:8081/fetchLibraryBook/id/'+paramId);
const items=await itemDetails.json();
console.log('==>',items)
setItems(items);

	
};

  return (
    <div>
      {items.map(it=>(
	  <h4 key={it.id}>
	  BookName :  {it.name}<br/>
	  BookAuthor : {it.bookAuthor}<br/>
	  BookSerialNO : {it.serialNo}<br/>
	  </h4>
	  ))}
    </div>
  );
}

export default Itemdetails;
