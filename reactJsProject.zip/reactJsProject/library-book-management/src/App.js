import React from 'react';
import './App.css';
import Nav from './Nav';
import Shop from './Shop';
import Itemdetails from './Itemdetails';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';

function App() {
  return (
   <Router>
    <nav>
      <Nav />
	  <Switch>
	  <Route path="/" exact component={Home}/>
	  <Route path="/shop" exact component={Shop}/>
	  <Route path="/shop/:id" component={Itemdetails}/>
	  </Switch>
    </nav>
	</Router>
  );
}

const Home=()=>(
<div>
<h3>Please Use above link to navigate to list of Libraies and Its related Books</h3>
</div>
);
export default App;
