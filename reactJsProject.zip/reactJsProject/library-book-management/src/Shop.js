import React,{useState,useEffect} from 'react';
import './App.css';
import axios from 'axios';
import {Link} from 'react-router-dom';

function Shop() {

	useEffect(() =>{
	fetchItems();
	},[]);

const [items,setItem]=useState([]);

const fetchItems=async()=>{
	const response = await fetch('http://127.0.0.1:8081/fetchLibraries');
    const items=await response.json();   
	console.log(items);
	setItem(items);
}

  return (
    <div>
      {items.map(item=>(
	  <h4 key={item.id}>
	  <Link to={'/shop/'+item.id}>{item.libraryName}</Link> <p style={{color: "red"}}>  Status   :  {item.status}</p></h4>
	  ))}
    </div>
  );
}

export default Shop;
